package application;

public class Global {

	public static Store store=new Store();

	
}
