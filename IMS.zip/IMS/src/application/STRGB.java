package application;

public class STRGB {

	
	public static int test;
	
}
